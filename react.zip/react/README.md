本仓库为`React`及`React-DOM`两个打包好的包，版本为`17.0.0-alpha.0`。

方便网络不好执行`yarn`命令安装依赖失败的同学。

## 使用方式

见：
https://react.iamkasong.com/preparation/source.html#%E6%8B%89%E5%8F%96%E6%BA%90%E7%A0%81